package examples.controller;


public class HelloControllerImpl {
	
	public String showHellow(){
		return "hello";
	}
	
}
