package org.seasar.cadhelin.annotation;

public @interface Action {
	String suffix() default "\0";
}
