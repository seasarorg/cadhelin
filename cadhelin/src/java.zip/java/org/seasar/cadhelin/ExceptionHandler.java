package org.seasar.cadhelin;

public interface ExceptionHandler {

}
